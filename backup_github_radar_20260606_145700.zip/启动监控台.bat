@echo off
title GitHub Radar Monitor

:: Ensure working directory is the script folder
cd /d "%~dp0"

echo ===================================================
echo Starting GitHub Monitor Dashboard...
echo ===================================================

:: Check for Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js was not found. Please install Node.js!
    pause
    exit /b
)

:: Run Express Server
start /b node src/app.js

:: Wait for server boot
timeout /t 3 /nobreak >nul

:: Open browser
echo Opening browser: http://localhost:3000
start http://localhost:3000

echo ===================================================
echo Startup complete!
echo   * Dashboard is opened in your default browser.
echo   * Background cron job is active (updates Bitable).
echo   * Direct close this terminal window to stop server.
echo ===================================================
pause
